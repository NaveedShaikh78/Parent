import tkinter.ttk as Tkk
import tkinter as tk
import json

root = tk.Tk()
#root.attributes('-fullscreen',True)
root.geometry('400x300')
#root.config(bg='#9FD996')/aswe3
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
#The weight determines how wide the column will occupy, which is relative to other columns.
root.grid_rowconfigure(11, weight=20)
#root.grid_rowconfigure(15, weight=1)
root.resizable(width=True, height=True)
bigfont = ('Times', 16)
#root.option_add("*TCombobox*Listbox*Font", bigfont)
settings ={}
with open ('setting.json') as data_file:
        settings = json.load(data_file)

root.option_add("*Font", bigfont)

bouds = (1200,2400,4800,9600,19200,38400,57600,115200)
slected_boud = tk.IntVar(value = settings['Baud'])

data_bits = (8,7)
data_bit = tk.IntVar(value = settings['DataBit'])

parity_list = ('Even', 'Odd', 'None')
parity = tk.StringVar(value = settings['Parity'])

stop_bits = (1,2)
stop_bit = tk.IntVar(value = settings['StopBit'])

handshaks = ('XON/XOFF', 'RTS/CTS')
handshak = tk.StringVar(value = 'XON/XOFF')

networks = ('nectar1', 'nectar2')
network = tk.StringVar(value = 'nectar1')

network_pass = tk.StringVar(value = settings['Password'])

class Settings(tk.Frame):
    def __init__(self, master=None):
        tk.Frame.__init__(self, master)
        tk.Label(padx = 5, anchor="w", text="Boud Rate").grid( row=0, column=0, sticky='WENS')
        tk.Label(padx = 5, anchor="w", text="Data Bit").grid( row=1, column=0, sticky='WENS')
        tk.Label(padx = 5, anchor="w", text="Parity").grid( row=2, column=0, sticky='WENS')
        tk.Label(padx = 5, anchor="w", text="Stop bits").grid( row=3, column=0, sticky='WENS')
        tk.Label(padx = 5, anchor="w", text="Hand Shake").grid( row=4, column=0, sticky='WENS')
        tk.Label(padx = 5, anchor="w", text="Network").grid( row=5, column=0, sticky='WENS')
        tk.Label(padx = 5, anchor="w", text="Password").grid( row=6, column=0, sticky='WENS')
        tk.Label(padx = 5, anchor="w", text="").grid( row=8, column=0, sticky='WENS')
        
        combo = Tkk.Combobox(values = bouds, textvariable = slected_boud, state ='readonly')
        combo.grid(  column=1, row=0, columnspan=2, sticky='WENS')

        combo = Tkk.Combobox(values = data_bits, textvariable = data_bit, state ='readonly')
        combo.grid(  column=1, row=1, columnspan=2, sticky='WENS')

        combo = Tkk.Combobox(values = parity_list, textvariable = parity, state ='readonly')
        combo.grid(  column=1, row=2, columnspan=2, sticky='WENS')
        
        combo = Tkk.Combobox(values = stop_bits, textvariable = stop_bit, state ='readonly')
        combo.grid(  column=1, row=3, columnspan=2, sticky='WENS')

            
        combo = Tkk.Combobox(values = handshaks, textvariable = handshak, state ='readonly')
        combo.grid(  column=1, row=4, columnspan=2, sticky='WENS')

    
        combo = Tkk.Combobox(values = networks, textvariable = network, state ='readonly')
        combo.grid(  column=1, row=5, columnspan=2, sticky='WENS')

        tk.Entry(show='*',textvariable = network_pass).grid( row=6, column=1, columnspan=2, sticky='WENS')

        tk.Button(text='Main').grid( row=15, column=0, sticky='WENS')
        tk.Button(text='Save', command = save_clicked).grid( row=15, column=1, sticky='WENS')
        tk.Button(text='Close').grid( row=15, column=2, sticky='WENS')

def save_clicked():
    with open('setting.json', 'w') as f:
        json.dump(settings, f, ensure_ascii=False)
app = Settings(master=root)
app.mainloop()
