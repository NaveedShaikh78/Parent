import tkinter as tk
root = tk.Tk()
#root.attributes('-fullscreen',True)
root.geometry('400x300')
#root.config(bg='#9FD996')/aswe3
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
root.grid_rowconfigure(0, weight=1)
#The weight determines how wide the column will occupy, which is relative to other columns.
root.grid_rowconfigure(1, weight=20)
root.grid_rowconfigure(2, weight=1)
root.resizable(width=True, height=True)

langs = ('Java', 'C#', 'C', 'C++', 'Python',
        'Go', 'JavaScript', 'PHP', 'Swift')

langs_var = tk.StringVar(value=langs)
listBoxFont = ('Times', 16)
class AppMain(tk.Frame):
    def __init__(self, master=None):
        tk.Frame.__init__(self, master)
        tk.Button(text='Main').grid( row=2, column=0, sticky='WENS')
        tk.Button(text='Select').grid( row=2, column=1, sticky='WENS')
        tk.Button(text='Setting').grid( row=2, column=2, sticky='WENS')
        tk.Listbox(listvariable=langs_var, font=listBoxFont).grid(  column=0, row=1, columnspan=3, sticky='WENS')
app = AppMain(master=root)
app.mainloop()
